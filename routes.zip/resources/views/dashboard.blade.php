@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')
@section('page-subtitle', 'Ringkasan aktivitas sesuai role Anda')

@section('content')

<div class="card mb-5">
    <div class="card-body p-4" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px">
        <div>
            <div style="font-size:18px; font-weight:600; color:var(--text)">Halo, {{ $user->name }} 👋</div>
            <p class="small text-muted mb-0">Role: <strong>{{ $role }}</strong> &middot; {{ $user->department ?? '—' }}</p>
        </div>
        <div class="status-badge active">{{ now()->translatedFormat('l, d F Y') }}</div>
    </div>
</div>

@include('dashboards.' . $roleView, ['data' => $data, 'user' => $user])

@if(isset($monitoringStats))
<div class="d-flex justify-content-between align-items-center mb-4 mt-5">
    <div>
        <span class="section-eyebrow">Monitoring Operasional</span>
        <h2 class="section-title" style="font-size:20px">Grafik Bahan Bakar &middot; Kendaraan &middot; Kebersihan WC</h2>
    </div>
</div>

<div class="row g-4 mt-2">
    @can('fuel.view')
    <div class="col-lg-4">
        <div class="card">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border)"><span class="metric-label">Pengeluaran BBM Bulanan</span></div>
            <div class="card-body p-3"><canvas id="chartFuelMonthly" height="220"></canvas></div>
        </div>
    </div>
    @endcan

    @can('toilet.view')
    <div class="col-lg-4">
        <div class="card">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border)"><span class="metric-label">Aktivitas Inspeksi WC (7 Hari)</span></div>
            <div class="card-body p-3"><canvas id="chartToiletActivity" height="220"></canvas></div>
        </div>
    </div>
    @endcan

    @can('vehicle.view')
    <div class="col-lg-4">
        <div class="card">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border)"><span class="metric-label">Kendaraan Berdasarkan Status</span></div>
            <div class="card-body p-3"><canvas id="chartVehicleStatus" height="220"></canvas></div>
        </div>
    </div>
    @endcan
</div>
@endif

@endsection

@if(isset($monitoringStats))
@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    @can('fuel.view')
    new Chart(document.getElementById('chartFuelMonthly'), {
        type: 'bar',
        data: {
            labels: @json($monitoringCharts['fuel_monthly_spending']->pluck('label')),
            datasets: [{ label: 'Pengeluaran BBM (Rp)', data: @json($monitoringCharts['fuel_monthly_spending']->pluck('total')), backgroundColor: '#f59e0b', borderRadius: 6 }],
        },
        options: { responsive: true, plugins: { legend: { display: false } } },
    });
    @endcan

    @can('toilet.view')
    new Chart(document.getElementById('chartToiletActivity'), {
        type: 'line',
        data: {
            labels: @json($monitoringCharts['toilet_activity']->pluck('label')),
            datasets: [
                { label: 'Total Inspeksi', data: @json($monitoringCharts['toilet_activity']->pluck('total')), borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,.15)', tension: 0.35, fill: true },
                { label: 'Status Kotor', data: @json($monitoringCharts['toilet_activity']->pluck('kotor')), borderColor: '#e11d48', backgroundColor: 'rgba(225,29,72,.1)', tension: 0.35, fill: true },
            ],
        },
        options: { responsive: true },
    });
    @endcan

    @can('vehicle.view')
    new Chart(document.getElementById('chartVehicleStatus'), {
        type: 'doughnut',
        data: {
            labels: ['Aktif', 'Servis', 'Tidak Aktif'],
            datasets: [{
                data: [
                    {{ $monitoringStats['vehicle']['unit_aktif'] }},
                    {{ $monitoringStats['vehicle']['unit_servis'] }},
                    {{ $monitoringStats['vehicle']['unit_tidak_aktif'] }},
                ],
                backgroundColor: ['#0ea5e9', '#f59e0b', '#e11d48'],
            }],
        },
        options: { responsive: true },
    });
    @endcan
});
</script>
@endpush
@endif
