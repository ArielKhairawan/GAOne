<div class="row g-4 mb-4">

    <div class="col-xl-3 col-md-6">
        <div class="metric-card">
            <div class="metric-top">
                <div>
                    <div class="metric-label">
                        Total User
                    </div>

                    <div class="metric-value">
                        {{ $data['total_user'] }}
                    </div>

                    <div class="metric-desc">
                        Pengguna aktif sistem
                    </div>
                </div>

                <div class="report-icon"
                     style="background:rgba(37,99,235,.08);">
                    👤
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="metric-card">
            <div class="metric-top">
                <div>
                    <div class="metric-label">
                        Kendaraan Aktif
                    </div>

                    <div class="metric-value">
                        {{ $data['total_kendaraan'] }}
                    </div>

                    <div class="metric-desc">
                        Monitoring operasional
                    </div>
                </div>

                <div class="report-icon"
                     style="background:rgba(16,185,129,.08);">
                    🚗
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="metric-card">
            <div class="metric-top">
                <div>
                    <div class="metric-label">
                        Permintaan ATK
                    </div>

                    <div class="metric-value">
                        {{ $data['total_permintaan_atk'] }}
                    </div>

                    <div class="metric-desc">
                        Request yang tercatat
                    </div>
                </div>

                <div class="report-icon"
                     style="background:rgba(245,158,11,.08);">
                    📦
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="metric-card">
            <div class="metric-top">
                <div>
                    <div class="metric-label">
                        Total Notifikasi
                    </div>

                    <div class="metric-value">
                        {{ $data['total_notifikasi'] }}
                    </div>

                    <div class="metric-desc">
                        Aktivitas terbaru
                    </div>
                </div>

                <div class="report-icon"
                     style="background:rgba(239,68,68,.08);">
                    🔔
                </div>
            </div>
        </div>
    </div>

</div>

<div class="row g-4 mb-4">

    <div class="col-xl-6 col-md-6">
        <div class="metric-card">
            <div class="metric-label">
                Total Pengeluaran BBM
            </div>

            <div class="metric-value">
                Rp {{ number_format($data['total_pengeluaran_bbm'],0,',','.') }}
            </div>

            <div class="metric-desc">
                Akumulasi pengeluaran operasional kendaraan
            </div>
        </div>
    </div>

    <div class="col-xl-6 col-md-6">
        <div class="metric-card">
            <div class="metric-label">
                Aktivitas Operasional
            </div>

            <div class="metric-value">
                {{
                    $data['total_booking_meeting']
                    +
                    $data['total_permintaan_konsumsi']
                    +
                    $data['total_inspeksi_wc']
                }}
            </div>

            <div class="metric-desc">
                Booking meeting, konsumsi dan inspeksi
            </div>
        </div>
    </div>

</div>

@include('dashboards.partials.notifications', [
    'notifications' => $data['notifications']
])
