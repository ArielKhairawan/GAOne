<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'GAOne') — Semen Andalas</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
<div class="app-layout">

    <!-- ═══════════════════════════════════════════
         SIDEBAR
    ═══════════════════════════════════════════ -->
    <aside class="sidebar">

        <div class="sidebar-header">
            <div class="sidebar-brand">
                <div class="sidebar-logo-icon">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 21V8l8-5 8 5v13H4zm2-2h3v-3H6v3zm0-5h3v-3H6v3zm5 5h3v-3h-3v3zm0-5h3v-3h-3v3zm5 5h3v-3h-3v3zm0-5h3v-3h-3v3zM11 3.5V7h2V3.5h-2z"/>
                    </svg>
                </div>
                <div class="sidebar-brand-text">
                    <h4>GAOne</h4>
                    <small>Semen Andalas System</small>
                </div>
            </div>
        </div>

        <nav class="sidebar-nav">
            @include('layouts.sidebar.index')
        </nav>

        <div class="sidebar-footer">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn-outline-secondary btn-sm" style="width:100%; justify-content: center;">
                    <svg viewBox="0 0 24 24" fill="currentColor" style="width:14px;height:14px">
                        <path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/>
                    </svg>
                    Sign Out
                </button>
            </form>
        </div>

    </aside>

    <!-- ═══════════════════════════════════════════
         MAIN CONTENT
    ═══════════════════════════════════════════ -->
    <div class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="page-title">@yield('page-title', 'Dashboard')</div>
                <div class="page-subtitle">@yield('page-subtitle', 'Selamat datang di GAOne')</div>
            </div>
            <div class="topbar-right">
                <span class="topbar-greeting d-none d-md-inline">Halo, {{ auth()->user()->name ?? 'Admin GA' }}</span>
                <a href="{{ route('profile.edit') }}" class="btn-profile">
                    <svg viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;color:var(--text-3)">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                    Profil
                </a>
            </div>
        </header>

        <!-- CONTENT -->
        <main class="content">
            @if(session('success') || session('status'))
                <div class="alert alert-success">{{ session('success') ?? session('status') }}</div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            @if($errors->any() && !request()->routeIs('login') && !request()->routeIs('register'))
                <div class="alert alert-danger">{{ $errors->first() }}</div>
            @endif
            @yield('content')
        </main>

    </div>

</div>
@stack('scripts')
</body>
</html>
