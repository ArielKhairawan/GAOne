@can('meeting.view')
    <div class="sidebar-group">Meeting & Konsumsi</div>

    <a href="{{ route('meeting.bookings.index') }}" class="{{ request()->routeIs('meeting.bookings.*') ? 'active' : '' }}">
        <svg class="nav-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"/></svg>
        Booking Ruang Meeting
    </a>

    @can('meeting.edit')
    <a href="{{ route('meeting.rooms.index') }}" class="{{ request()->routeIs('meeting.rooms.*') ? 'active' : '' }}">
        <svg class="nav-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L2 12h3v8h6v-5h2v5h6v-8h3L12 3z"/></svg>
        Master Ruangan
    </a>
    @endcan

    @can('consumption.view')
    <a href="{{ route('consumption.index') }}" class="{{ request()->routeIs('consumption.*') ? 'active' : '' }}">
        <svg class="nav-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M8.1 13.34l2.83-2.83L3.91 3.5c-1.56 1.56-1.56 4.09 0 5.66l4.19 4.18zm6.78-1.81c1.53.71 3.68.21 5.27-1.38 1.91-1.91 2.28-4.65.81-6.12-1.46-1.46-4.20-1.10-6.12.81-1.59 1.59-2.09 3.74-1.38 5.27L3.7 19.87l1.41 1.41L12 14.41l6.88 6.88 1.41-1.41L13.41 13l1.47-1.47z"/></svg>
        Permintaan Konsumsi
    </a>
    @endcan
@endcan
